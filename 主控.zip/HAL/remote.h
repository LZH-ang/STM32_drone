#ifndef _REMOTE_H
#define _REMOTE_H

extern void RC_Analy(void);

#endif

