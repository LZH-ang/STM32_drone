#ifndef _SPI_H_
#define _SPI_H_
#include "stm32f10x.h"


void SPI_Config(void);
u8 SPI_RW(u8 dat);

#endif
