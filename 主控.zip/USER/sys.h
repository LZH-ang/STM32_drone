#ifndef __SYS_H
#define __SYS_H

//#pragma pack(push,4) 
//#pragma pack(4) 
//__unaligned
//__packed
//__align(4)

#include "delay.h"      //system delay,common.


extern void ALL_Init(void);

#endif

/******************************END OF FILE *******************************************/

